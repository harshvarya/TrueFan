package com.truefan.taskmgmt.dto;

public class TaskDto {
    private String details;

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    private String activityType;

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }}
