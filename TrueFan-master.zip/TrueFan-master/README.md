# TrueFan
TrueFan Assignment

Go to each of the following application's READ.md file to execute individual application

1. SUBMISSION_A : Pure Java based application
2. SUBMISSION_B : Spring Boot based REST api with no db
3. SUBMISSION_C : Spring Boot based REST api with in memory H2 db
